package jaeyong.Test2.Controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContentFrom {
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
